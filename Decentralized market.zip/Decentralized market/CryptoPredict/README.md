# CryptoPredict
![CryptoPredict Image](https://github.com/CoderEren/CryptoPredict/blob/main/social_media_assets/twitterheader.png?raw=true)

Currently, the prediction markets or betting platforms are centralised and the code that is used to run the site and algorithms beneath are behind closed curtains.
My project is a Decentralised Prediction Market used to predict the price movements of Bitcoin in the next hour. It is governed by algorithms written on Solidity smart contracts which are immutable (can’t be changed) and transparent (anyone can access the source code). In the first hour of the round creation, the predictors can place their predictions whether the price of Bitcoin is going to go up or down in the next hour. Their funds are locked in the prize pool of the smart contract. In the second hour, predictors can no longer place their predictions. At the end of the second hour, the winning side is determined by retrieving the current price of Bitcoin from decentralised data feeds of Chainlink. The losing side loses their bets and the winning side shares the losing side’s funds in proportion to the amount of money they betted, on top of their initial bets.

## Code
The Solidity contract is located in the contract.sol file. Users call the bullBet function by predicting up and bearBet function by predicting down. A certain commission is taken from the bets and the rest are placed. After the round is over, the current price of Bitcoin is retrieved from the decentralised data feeds of Chainlink. Then, the current price is compared to the price an hour before. If the user predicted the price movement correctly, they get their initial bets and a percentage of the prize pool which is in proportion to the amount of money they bet.

I also started developing a token for this project but haven't completely finished it.
Early users would be able to participate in the presale until enough tokens were sold at a fixed price or the presale was closed manually. The commissions earned from the CryptoPredict platform would be used to buyback $CRP tokens and burn those tokens. This would lead to a lower supply of tokens, therefore increasing the value of each token. So, in a way, holders of $CRP tokens would be investing in the success of CryptoPredict.



![CryptoPredict Image](https://github.com/CoderEren/CryptoPredict/blob/main/social_media_assets/cryptopredictss.png?raw=true)

![CryptoPredict Image](https://github.com/CoderEren/CryptoPredict/blob/main/social_media_assets/Bet%20on%20your%20beliefs%20(1).png?raw=true)

## Existing Similar Solutions
### PancakeSwap Prediction
PancakeSwap Prediction is a Decentralised Prediction Market that enables users to predict the price movements of BNB (the native token of the Centralised Crypto Exchange Binance) or Cake (the native token of the PancakeSwap platform). The contract is deployed on the Binance Smart Chain. Each round lasts 5 minutes. This makes the project feel more like a gambling platform rather than a prediction market because the price of the coin does not move significantly during a 5-minute interval. Also, the market cap of the CAKE token ($634M as of 11/10/2022) is significantly lower than the market cap of Bitcoin ($364B as of 11/10/2022), making the bets more vulnerable to fluctuating price movements that can be manipulated by buying and selling made by large investors (called ‘whales’ in the cryptocurrency community). 
### PolyMarket
PolyMarket is a decentralised prediction market on the Polygon network used to predict the outcomes of global events happening. These events range across categories in politics, sports, crypto to business and more. The outcomes are simply ‘Yes’ and ‘No’ and you buy shares based on which outcome you think is going to happen. Then your shares either go up or down in value depending on the outcome and how many more people buy or sell their shares after you purchased your shares.
